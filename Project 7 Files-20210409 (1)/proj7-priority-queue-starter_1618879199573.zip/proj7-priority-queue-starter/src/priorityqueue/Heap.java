package priorityqueue;

import java.util.Comparator;

public class Heap<T> implements PriorityQueueADT<T> {

  private int numElements;
  private T[] heap;
  private boolean isMaxHeap;
  private Comparator<T> comparator;
  private final static int INIT_SIZE = 5;
  
  /**
   * Constructor for the heap.
   * @param comparator comparator object to define a sorting order for the heap elements.
   * @param isMaxHeap Flag to set if the heap should be a max heap or a min heap.
   */
  public Heap(Comparator<T> comparator, boolean isMaxHeap) {
      //TODO: Implement this method.
      heap = (T[]) new Object[INIT_SIZE];
      for(int i = 0; i < heap.length; i++){
        heap[i] = null; 
      }
      this.isMaxHeap = isMaxHeap;  
      this.comparator = comparator;
      this.numElements = 0; 
      
  }
  
  /**
   * This results in the entry at the specified index "bubbling up" to a location
   * such that the property of the heap are maintained. This method should run in
   * O(log(size)) time.
   * Note: When enqueue is called, an entry is placed at the next available index in 
   * the array and then this method is called on that index. 
   *
   * @param index the index to bubble up
   */
  public void bubbleUp(int index) {
      //TODO: Implement this method.
    while(index > 0){
      int parentIndex = (index - 1) / 2; 
      if(compare(heap[index], heap[parentIndex]) <= 0){
        return; 
      }
      else{
        swap(index, parentIndex);
        index = parentIndex;  
      }
    }

  /**if(index < 0 || index > numElements){
     throw new IndexOutOfBoundsException();
  }
      
  int parent = (index - 1) / 2;

  if(index == 0){
     return; 
  }
  if (compare(heap[parent], heap[index]) <= 0) {
    swap(index, parent);
    bubbleUp(parent);
  }**/ 
  
    
  }
  //helper methods 
private int getLeftChild(int index){
  if(index < 0){
    throw new IndexOutOfBoundsException();
  }
    return index*2+1;
}

private int getRightChild(int index){
  if(index < 0){
    throw new IndexOutOfBoundsException();
  }
    return index*2+2;
}

private int getParentOf(int index){
  return index/2; 
}


private void swap(int i, int j){
      T temp;
      temp = heap[i];
      heap[i] = heap[j];
      heap[j] = temp; 

}

  /**
   * This method results in the entry at the specified index "bubbling down" to a
   * location such that the property of the heap are maintained. This method
   * should run in O(log(size)) time.
   * Note: When remove is called, if there are elements remaining in this
   *  the bottom most element of the heap is placed at
   * the 0th index and bubbleDown(0) is called.
   * 
   * @param index
   */
  public void bubbleDown(int index) {
      //TODO: Implement this method.
      int childIndex = 2 * index + 1; 
      T val = heap[index];
      while(childIndex < size()){
        T max = val; 
        int indexMax = -1; 
        for(int i = 0; i < 2 && (i + childIndex)< size(); i++){
          if(compare(heap[i+childIndex], max) > 0){
            max = heap[i + childIndex];
            indexMax = i + childIndex;
          }
        }
        if(max == val){
          return;
        }
        else{
          swap(index, indexMax);
          index = indexMax; 
          childIndex = 2 * index + 1; 
        }
      }
      /**if(index < 0 || index > numElements){
        throw new IndexOutOfBoundsException();
      }
      int childRight = getRightChild(index); 
      int childLeft = getLeftChild(index);
      int large;

      if(childLeft >= size()-1){
        if(childLeft == size()-1){
          large = childLeft; 
        }
        return;
      }
      else{
        if(heap[index]== null || heap[childLeft] == null){
          return; 
       }
        if(heap[childRight] == null){
          return;
        }
        if(size() == 1 || index >= size()/2){
          return; 
        }
        //if(size() == 2 && (comparator.compare(heap[index], heap[childLeft])>0)){
          //swap(index, childLeft);
        //}
        if(comparator.compare(heap[childLeft], heap[childRight]) >0 && (childLeft < numElements) && (childRight < numElements)){
          large = childLeft; 
        }
       else{
        large = childRight; 
        }
      }

     if(comparator.compare(heap[index], heap[large])<0){
       swap(index,large);
       bubbleDown(large);
     }**/ 
  }

  
  /**
   * Test for if the queue is empty.
   * @return true if queue is empty, false otherwise.
   */
  public boolean isEmpty() {
    boolean isEmpty = false;
      //TODO: Implement this method.
     if(size() == 0){
       isEmpty = true; 
      }
      
    return isEmpty;
  }
  
  /**
   * Number of data elements in the queue.
   * @return the size
   */
  public int size(){
    int size = -100;
      //TODO: Implement this method.
      //if(isEmpty()){
       // size = 0; 
      //}
      size = numElements; 
        return size;
  }

  /**
   * Compare method to implement max/min heap behavior.  It calls the comparae method from the 
   * comparator object and multiply its output by 1 and -1 if max and min heap respectively.
   * TODO: implement the heap compare method
   * @param element1 first element to be compared
   * @param element2 second element to be compared
   * @return positive int if {@code element1 > element2}, 0 if {@code element1 == element2}, negative int otherwise
   */
  public int compare(T element1 , T element2) {
    int result = 0;
    int compareSign =  -1;
    if (isMaxHeap) {
      compareSign = 1;
    }
    result = compareSign * comparator.compare(element1, element2);
    return result;
  }

  /**
   * Return the element with highest (or lowest if min heap) priority in the heap 
   * without removing the element.
   * @return T, the top element
   * @throws QueueUnderflowException if empty
   */
  public T peek() throws QueueUnderflowException {
     T data = null;
      //TODO: Implement this method.
      if(isEmpty()){
        throw new QueueUnderflowException();
      }
      data = heap[0]; 

    return data;
  }  

  /**
   * Removes and returns the element with highest (or lowest if min heap) priority in the heap.
   * @return T, the top element
   * @throws QueueUnderflowException if empty
   */
  public T dequeue() throws QueueUnderflowException{
    T data = null;
      //TODO: Implement this method.
      if(isEmpty()){
        throw new QueueUnderflowException();
      }
      data = heap[0];
      if(size() == 1){
        heap[0] = null;
        numElements--; 
      }
      else{
        swap(0, size()-1);
        //heap[0] = heap[size()-1];
        //heap[size()-1] = null;
        T[] newH = (T[]) new Object[size()-1]; 
        for(int i = 0; i < size()-1; i++){
          newH[i] = heap[i];
        }
        heap = newH; 
        numElements--; 
        bubbleDown(0);
        
      }
    return data;
  }
  
  /**
   * Enqueue the element.
   * @param the new element
   */
  public void enqueue(T newElement) {
      //TODO: Implement this method.
      if(newElement == null){
        throw new NullPointerException(); 
      }
      if(numElements == heap.length){
        expandCapacity();
      }
      if(isEmpty()){
        heap[0] = newElement; 
      }
      else{
        heap[size()] = newElement; 
        bubbleUp(size()); 
      }
      numElements++;
      //heap[numElements] = newElement; 
         // bubbleUp(numElements);
          //numElements++;
  }

  public void expandCapacity() {
    T[] newArray = (T[]) new Object[numElements * 2];
    for(int i  = 0; i < heap.length; i ++){
      newArray[i] = heap[i];
    }
    heap = newArray;
  } 
}