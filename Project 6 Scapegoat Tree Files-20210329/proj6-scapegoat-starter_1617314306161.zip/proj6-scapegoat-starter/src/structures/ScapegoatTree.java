package structures;

public class ScapegoatTree<T extends Comparable<T>> extends BinarySearchTree<T> {
  private int upperBound;


  @Override
  public void add(T t) {
    // TODO: Implement the add() method
    upperBound++;
		root = addHelper(t, root);
		
		double check = Math.log(upperBound) / Math.log(3.0/2.0);
		
		if (height() > check) {
			balance();
		}
  }

  private BSTNode<T> addHelper(T elem, BSTNode<T> curr) {
		if (curr == null) {
			return new BSTNode<T>(elem, null, null);
		}
		if (elem.compareTo(curr.getData()) <= 0) {
			curr.setLeft(addHelper(elem, curr.getLeft()));
		} else {
			curr.setRight(addHelper(elem, curr.getRight()));
		}
		return curr;
  }
  
  @Override
  public boolean remove(T element) {
    // TODO: Implement the remove() method
    upperBound--;
    boolean res = contains(element);
		if (res) {
			root = removeHelper(root, element);
		}
		
		if (this.height() > Math.log(upperBound) / Math.log(3.0/2.0)) {
			this.balance();
		}
		
		return res;

    //return false;
  }
  //helper method for remove
  private BSTNode<T> removeHelper(BSTNode<T> curr, T node) {
		// node must not be null
		int result = node.compareTo(curr.getData());
		if (result < 0) {
			curr.setLeft(removeHelper(curr.getLeft(), node));
			return curr;
		} else if (result > 0) {
			curr.setRight(removeHelper(curr.getRight(), node));
			return curr;
    } 
    else { 
			if (curr.getLeft() == null) {
				return curr.getRight();
			} else if (curr.getRight() == null) {
				return curr.getLeft();
      } 
      else { 
				T predecessorValue = getHigh(curr.getLeft());
				curr.setLeft(removeRight(curr.getLeft()));
				curr.setData(predecessorValue);
				return curr;
			}
		}
  }
  private T getHigh(BSTNode<T> curr) {
		if (curr.getRight() == null) {
			return curr.getData();
		} else {
			return getHigh(curr.getRight());
		}
  }
  private BSTNode<T> removeRight(BSTNode<T> curr) {
		if (curr.getRight() == null) {
			return curr.getLeft();
		} else {
			curr.setRight(removeRight(curr.getRight()));
			return curr;
		}
	}

  public static void main(String[] args) {
    BSTInterface<String> tree = new ScapegoatTree<String>();
    /*
    You can test your Scapegoat tree here.
    for (String r : new String[] {"0", "1", "2", "3", "4"}) {
      tree.add(r);
      System.out.println(toDotFormat(tree.getRoot()));
    }
    */
  }
}
